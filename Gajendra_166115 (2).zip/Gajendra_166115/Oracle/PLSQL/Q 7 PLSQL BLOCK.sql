DECLARE
	v_total_discount Campus.CampusDiscount%TYPE;
BEGIN
	SELECT SUM(CampusDiscount) INTO v_total_discount FROM Campus;
	IF v_total_discount < 01.00 THEN
		UPDATE Campus
			SET 
			CampusDiscount = 2.00;
	END IF;
	
END;
/
set serveroutput on;
declare
member number;

BEGIN
	member:= &id;
	Oreder_Food_Items( member );
end;
/