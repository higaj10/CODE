CREATE OR REPLACE PROCEDURE Oreder_Food_Items( Member_ID in Number )
as
	CURSOR c_Food_Names IS SELECT FoodItemName 
			FROM  Orders O, FoodItems F, OrderLine OL 
			WHERE  O.OrderID = OL.OrderID AND OL.FoodItemsID = F.FoodItemID AND MemberID = Member_ID;
	v_cnt number;
	NO_ROWS_FOUNDS EXCEPTION;
BEGIN
	SELECT FoodItemName INTO v_cnt
			FROM  Orders O, FoodItems F, OrderLine OL 
			WHERE  O.OrderID = OL.OrderID AND OL.FoodItemsID = F.FoodItemID AND MemberID = Member_ID;
			
	IF v_cnt =0 THEN 
		RAISE NO_ROWS_FOUNDS;
	ELSE
	FOR Food_Name in c_Food_Names
	LOOP
	dbms_output.put_line( Food_Name.FoodItemName );
	--DBMS_OUTPUT.PUT_LINE( Food_Name );
	END LOOP;

		
	END IF;
	EXCEPTION
		WHEN NO_ROWS_FOUNDS THEN
			dbms_output.put_line('No Rows  Found');
		WHEN OTHERS THEN
			dbms_output.put_line('Other Errors');
END;
/
set serveroutput on;
declare
member number;

BEGIN
	member:= &id;
	Oreder_Food_Items( member );
end;
/