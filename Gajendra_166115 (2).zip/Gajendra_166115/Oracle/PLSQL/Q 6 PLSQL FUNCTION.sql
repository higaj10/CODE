CREATE OR REPLACE FUNCTION Total_Quabtity( v_position in VARCHAR2 ) RETURN NUMBER
as
	v_cnt OrderLine.Quantity%TYPE;
BEGIN
	
	SELECT COUNT( OL.Quantity ) INTO v_cnt
			FROM Members M, Orders O, Position P, OrderLine OL 
			WHERE M.MemberID = O.MemberID AND O.OrderID = OL.OrderID AND M.PositionID = P.PositionID
				AND Position = v_position;
	IF v_cnt=0 THEN
		dbms_output.put_line('No positon Find');
		RETURN NULL;
	END IF;
	EXCEPTION
		WHEN OTHERS THEN
			dbms_output.put_line('Other Errors');
			RETURN NULL;
	RETURN v_cnt;
END;
/


set serveroutput on;

declare
v OrderLine.Quantity%TYPE;
BEGIN
	v:=Total_Quabtity( 'Lecturer' );
	dbms_output.put_line( v);
end;
/

Lecturer

OUTPUT 9








