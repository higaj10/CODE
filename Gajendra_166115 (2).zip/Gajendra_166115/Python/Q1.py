#Input a list from user
entered_list = input("Enter a list\n").split( ' ' ) # Split list element by space
#Input a word which have to remove from user
r_word = input("Enter a word which have to remove\n")

#Input occurence number of word from user
occurence_no = int(input("Enter ith occurence of word which have to remove\n"))
list_occurence_word = [] #List to store all occurence no. of word
# Enumerate gives all words position
for i, word in enumerate( entered_list ) : 
    if word == r_word :
        list_occurence_word.append(i)
# to check ith occurence in list
if (len(list_occurence_word)) < occurence_no:
    print (occurence_no, "Times occurence not in list\n")
else:
    del entered_list[list_occurence_word[occurence_no-1]] #delete ith occurence

print (entered_list )
