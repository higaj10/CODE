package com.StudentDetails;

import java.util.Scanner;

public class StudentEducational {
	//Enter the Variables names
	int rollNo;
	double avgMark;
	int Attendace;
	//Create a constructors using feilds
	public StudentEducational(int rollNo, double avg, int attendace) {
		super();
		this.rollNo = rollNo;
		this.avgMark = avg;
		this.Attendace = attendace;
	}
	// Display them
	void display()
	{
		System.out.println("-----------STUDENT EDUCATIONAL DETAILS---------");
		System.out.println("Roll no of the Student "+ rollNo);
		System.out.println("Average marks   of the Student "+ avgMark);
		System.out.println("Attendance  of the Student "+ Attendace+"%");
	}
	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		System.out.println("enter the roll no ");
		int rollNo=s.nextInt();
		System.out.println("enter the Average marks");
		int AvgMark=s.nextInt();
		System.out.println("enter the Attendane ");
		int Attendance=s.nextInt();
		StudentEducational s1= new StudentEducational(rollNo, AvgMark, Attendance);
		s1.display();
		
	}
	
	

}/*
output
-----------STUDENT EDUCATIONAL DETAILS---------
Roll no of the Student 1234
Average marks   of the Student 679.0
Attendance  of the Student 95%
*/