package com.StudentDetails;

import java.util.Scanner;

public class StudentPersonal 
{
	String studentName;
	int age;
	String sex;
	String address;
	String fatherName;
	String motherName;
	
	//to initialize the object use constructer 
	public StudentPersonal(String studentName, int age,String sex, String adress,
			String fatherName, String motherName) {
		studentName = studentName;
		this.age = age;
		this.sex=sex;
		this.address = adress;
		fatherName = fatherName;
		motherName = motherName;
	}
	//To display the Student details we have created a method
	void displayDetails()
	{
		System.out.println("-----------STUDENT PERSONAL DETAILS---------");
		System.out.println("Name of the Student is " +studentName);
		System.out.println("age of the Student is " +age);
		System.out.println("Student is " +sex);
		System.out.println("Name of the Father is " +fatherName);
		System.out.println("Name of the Mother is " +motherName);
	}
	public static void main(String[] args) {
		//input from user delcare s
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the Name");
		String Name=s.nextLine();
		System.out.println("Enter the age ");
		int age=s.nextInt();
		s.nextLine();
		System.out.println("Enter the sex");
		String sex=s.nextLine();
		System.out.println("Enter the address ");
		String Add=s.nextLine();
		System.out.println("Enter the Father's Name ");
		String name1=s.nextLine();
		System.out.println("Enter the Mother's Name ");
		String name2=s.nextLine();
		//initialize it in constructor with Input values
		StudentPersonal sp= new StudentPersonal(Name, age,sex, Add, name1, name2);//creating object of StudentPersonal class
		//display the details 
		sp.displayDetails();
	}
}
/*
OUTPUT
-----------STUDENT PERSONAL DETAILS---------
Name of the Student is Gajendra
age of the Student is 22
Student is M
Name of the Father is Mr.Bardi Singh
Name of the Mother is Mamta*/