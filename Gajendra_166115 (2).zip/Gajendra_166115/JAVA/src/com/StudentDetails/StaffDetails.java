
package com.StudentDetails;

import java.util.Scanner;

public class StaffDetails 
{
	//Enter the variables name
	String memberName;
	String designation;
	String position;
	//Initialing the constructors
	public StaffDetails(String memberName, String designation, String position) {
		this.memberName = memberName;
		this.designation = designation;
		this.position = position;
	}
	//Display the deatils using display()
	 void display()
	{
		 System.out.println("-----------STAFF DETAILS---------");
		System.out.println("Name of the staff Memeber : "+ memberName);
		System.out.println("Designation = "+designation);
		System.out.println("  His position  " + position );
	}
	 //generate main method 
	 public static void main(String[] args) {
		 Scanner s= new Scanner(System.in);//takig input from the user
			System.out.println("Enter the Name Of Staff");
			String StaffName=s.nextLine();
			System.out.println("Enter the designation ");
			String design=s.nextLine();
			System.out.println("Enter the position ");
			String position=s.nextLine();
		StaffDetails sd= new StaffDetails(StaffName, design, position);//creating object and initializing it
		sd.display();
		
	}

}

/*
OUTPUT
-----------STAFF DETAILS---------
Name of the staff Memeber : Dr Rajaram
designation = Faculty
His position  Professor
___*/